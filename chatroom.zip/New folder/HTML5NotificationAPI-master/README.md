# HTML5NotificationAPI
This code gives you idea about how to use HTML Desktop API notification bar.

Tutorial link:
https://www.youtube.com/playlist?list=PLkNK6gG5JPIaWIZg6rUKxNAUdEx4EwhWk

console.log('%c'+"STOP..! , THIS CONSOLE IS ONLY FOR ADMIN USE, YOU MAY GET BLOCKED FROM OUR CHATROOM IF YOU USE THIS CONSOLE.", 'font-weight: bold; font-size: 14px;color: red; text-shadow: 0px 0px 5px black; border: 2px Solid black; padding:6px; border-radius:10px; display:block;');
var foradmin='You are an admin & thats why you cannot ignore a user because your duty is to block users who violate, and if you ignore someone so you will not be able to see his messages.';        
        
// Initialize Firebase
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyD6QZLNLqIAzdh83jHAFLDUgkKjlh4f1vE",
    authDomain: "chatroom-e7870.firebaseapp.com",
    databaseURL: "https://chatroom-e7870.firebaseio.com",
    projectId: "chatroom-e7870",
    storageBucket: "chatroom-e7870.appspot.com",
    messagingSenderId: "324350719559"
  };
  firebase.initializeApp(config);



